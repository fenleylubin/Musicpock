#!/bin/bash

# Colors for better readability
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}===== MusicPock Demo Launcher =====${NC}"
echo -e "${BLUE}This script will start a local server to showcase the MusicPock interface${NC}"
echo ""

# Check for port argument
PORT=${1:-8000}

# Create a function to open the browser
open_browser() {
    echo -e "${YELLOW}Opening browser...${NC}"
    # Try to open browser based on OS
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        xdg-open "http://localhost:$PORT/demo/" &>/dev/null &
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        open "http://localhost:$PORT/demo/" &>/dev/null &
    elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
        start "http://localhost:$PORT/demo/" &>/dev/null &
    else
        echo -e "${YELLOW}Please open a browser and navigate to: http://localhost:$PORT/demo/${NC}"
    fi
}

# Function to start the server
start_server() {
    echo -e "${GREEN}Starting server on port $PORT...${NC}"
    echo -e "${BLUE}Access the demo at: ${YELLOW}http://localhost:$PORT/demo/${NC}"
    echo -e "${BLUE}Press Ctrl+C to stop the server${NC}"
    echo ""

    cd ../../

    # Start a simple HTTP server based on available technology
    if command -v python3 &> /dev/null; then
        open_browser
        echo -e "${GREEN}Using Python3 HTTP server...${NC}"
        python3 -m http.server $PORT
    elif command -v python &> /dev/null; then
        open_browser
        echo -e "${GREEN}Using Python HTTP server...${NC}"
        python -m SimpleHTTPServer $PORT
    elif command -v npx &> /dev/null; then
        echo -e "${GREEN}Using NPX serve...${NC}"
        # Serve opens the browser automatically
        npx serve -p $PORT
    elif command -v php &> /dev/null; then
        open_browser
        echo -e "${GREEN}Using PHP server...${NC}"
        php -S localhost:$PORT
    else
        echo -e "${YELLOW}No suitable server found. Please install Python, Node.js, or PHP, or manually start a server.${NC}"
        echo -e "${YELLOW}Then open: http://localhost:$PORT/demo/ in your browser${NC}"
        exit 1
    fi
}

# Show some options
echo "Select an option:"
echo "1) Start demo server on port $PORT"
echo "2) Change port"
echo "3) Exit"
read -p "Enter choice (1-3): " choice

case $choice in
    1)
        start_server
        ;;
    2)
        read -p "Enter new port number: " new_port
        if [[ $new_port =~ ^[0-9]+$ ]] && [ $new_port -gt 0 ] && [ $new_port -lt 65536 ]; then
            PORT=$new_port
            start_server
        else
            echo -e "${YELLOW}Invalid port number. Using default port $PORT${NC}"
            start_server
        fi
        ;;
    3)
        echo -e "${GREEN}Exiting. Goodbye!${NC}"
        exit 0
        ;;
    *)
        echo -e "${YELLOW}Invalid choice. Starting with default options.${NC}"
        start_server
        ;;
esac
