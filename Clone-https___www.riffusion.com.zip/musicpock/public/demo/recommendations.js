/**
 * MusicPock AI Recommendations System
 * This script simulates an AI-powered music recommendation system.
 * In a real implementation, this would call an API with ML models on the backend.
 */

class MusicRecommendations {
  constructor() {
    this.genres = [
      'Lo-Fi', 'Jazz', 'Electronic', 'Classical', 'Hip-Hop', 'Rock',
      'Ambient', 'Pop', 'Folk', 'R&B', 'Cinematic', 'Synth'
    ];

    this.moods = [
      'Relaxed', 'Energetic', 'Melancholic', 'Happy', 'Focused',
      'Dreamy', 'Dark', 'Uplifting', 'Romantic', 'Aggressive'
    ];

    this.instruments = [
      'Piano', 'Guitar', 'Drums', 'Synth', 'Saxophone', 'Strings',
      'Bass', 'Trumpet', 'Flute', 'Violin', 'Electric Guitar', 'Vocals'
    ];

    this.listeningHistory = [];
    this.userPreferences = {};
    this.recommendationsSection = null;
  }

  // Initialize the recommendations system
  init() {
    // Create recommendations section if it doesn't exist
    if (!document.getElementById('recommendations-section')) {
      this.createRecommendationsSection();
    }

    this.recommendationsSection = document.getElementById('recommendations-section');

    // Add event listeners
    const songRows = document.querySelectorAll('.song-row');
    songRows.forEach(row => {
      row.addEventListener('click', () => {
        const title = row.querySelector('.song-info h3').textContent;
        const artist = row.querySelector('.song-info p').textContent;
        this.trackSongInteraction(title, artist);
      });
    });

    const playlistCards = document.querySelectorAll('.playlist-card');
    playlistCards.forEach(card => {
      card.addEventListener('click', () => {
        const title = card.querySelector('.playlist-info h3').textContent;
        this.trackPlaylistInteraction(title);
      });
    });

    const promptTags = document.querySelectorAll('.prompt-tag');
    promptTags.forEach(tag => {
      tag.addEventListener('click', () => {
        const style = tag.textContent;
        this.trackStylePreference(style);
      });
    });

    // Generate initial recommendations
    this.generateRecommendations();

    // Set up interval to refresh recommendations
    setInterval(() => {
      this.generateRecommendations();
    }, 20000); // Refresh every 20 seconds
  }

  // Track song interactions
  trackSongInteraction(title, artist) {
    this.listeningHistory.push({
      type: 'song',
      title,
      artist,
      timestamp: new Date().getTime()
    });

    // Analyze the song to extract features - in a real implementation,
    // this would use ML to identify genre, mood, etc.
    this.analyzeSongFeatures(title);

    // Update recommendations based on new interaction
    this.generateRecommendations();
  }

  // Track playlist interactions
  trackPlaylistInteraction(title) {
    this.listeningHistory.push({
      type: 'playlist',
      title,
      timestamp: new Date().getTime()
    });

    // Update recommendations based on new interaction
    this.generateRecommendations();
  }

  // Track style preferences
  trackStylePreference(style) {
    if (!this.userPreferences.styles) {
      this.userPreferences.styles = {};
    }

    if (this.userPreferences.styles[style]) {
      this.userPreferences.styles[style]++;
    } else {
      this.userPreferences.styles[style] = 1;
    }

    // Update recommendations based on new preference
    this.generateRecommendations();
  }

  // Analyze song features (simplified simulation)
  analyzeSongFeatures(title) {
    const lowercaseTitle = title.toLowerCase();

    // Simple keyword matching to extract features
    // In a real implementation, this would use ML models
    this.genres.forEach(genre => {
      if (lowercaseTitle.includes(genre.toLowerCase())) {
        if (!this.userPreferences.genres) {
          this.userPreferences.genres = {};
        }

        if (this.userPreferences.genres[genre]) {
          this.userPreferences.genres[genre]++;
        } else {
          this.userPreferences.genres[genre] = 1;
        }
      }
    });

    this.moods.forEach(mood => {
      if (lowercaseTitle.includes(mood.toLowerCase())) {
        if (!this.userPreferences.moods) {
          this.userPreferences.moods = {};
        }

        if (this.userPreferences.moods[mood]) {
          this.userPreferences.moods[mood]++;
        } else {
          this.userPreferences.moods[mood] = 1;
        }
      }
    });
  }

  // Generate personalized recommendations
  generateRecommendations() {
    if (!this.recommendationsSection) return;

    // Get top preferences
    const topGenre = this.getTopPreference('genres');
    const topMood = this.getTopPreference('moods');
    const topStyle = this.getTopPreference('styles');

    // Create recommendations
    const recommendations = [];

    // Based on genre
    if (topGenre) {
      recommendations.push(this.createRecommendation(
        `Because you like ${topGenre} music`,
        this.generateSongTitle(topGenre),
        this.getRandomArtist(),
        `genre-${topGenre.toLowerCase().replace(/\s+/g, '-')}`
      ));
    }

    // Based on mood
    if (topMood) {
      recommendations.push(this.createRecommendation(
        `For a ${topMood.toLowerCase()} mood`,
        this.generateSongTitle(topMood),
        this.getRandomArtist(),
        `mood-${topMood.toLowerCase().replace(/\s+/g, '-')}`
      ));
    }

    // Based on style preference
    if (topStyle) {
      recommendations.push(this.createRecommendation(
        `Matches your ${topStyle} style preference`,
        this.generateSongTitle(topStyle),
        this.getRandomArtist(),
        `style-${topStyle.toLowerCase().replace(/\s+/g, '-')}`
      ));
    }

    // Add some general recommendations if we don't have enough
    while (recommendations.length < 3) {
      const randomGenre = this.genres[Math.floor(Math.random() * this.genres.length)];
      recommendations.push(this.createRecommendation(
        `New in ${randomGenre}`,
        this.generateSongTitle(randomGenre),
        this.getRandomArtist(),
        `genre-${randomGenre.toLowerCase().replace(/\s+/g, '-')}`
      ));
    }

    // Update the UI
    this.updateRecommendationsUI(recommendations);
  }

  // Get the top preference for a category
  getTopPreference(category) {
    if (!this.userPreferences[category]) return null;

    let topItem = null;
    let topCount = 0;

    Object.entries(this.userPreferences[category]).forEach(([item, count]) => {
      if (count > topCount) {
        topItem = item;
        topCount = count;
      }
    });

    return topItem;
  }

  // Generate a realistic song title based on input
  generateSongTitle(input) {
    const prefixes = [
      'Dreams of', 'Journey to', 'The', 'Midnight', 'Echoes of',
      'Forever', 'Lost in', 'Beyond', 'Endless', 'Whispers of'
    ];

    const suffixes = [
      'Harmony', 'Waves', 'Light', 'Horizon', 'Memories',
      'Reflections', 'Dimensions', 'Soul', 'Dreams', 'Moments'
    ];

    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];

    // 50% chance to use the input directly in the title
    if (Math.random() > 0.5) {
      return `${prefix} ${input}`;
    } else {
      return `${prefix} ${suffix}`;
    }
  }

  // Get a random artist name
  getRandomArtist() {
    const artists = [
      'Cosmic Harmony', 'Dreamweaver', 'Nebula Sounds', 'Echo Valley',
      'Quantum Beats', 'Stellar Waves', 'Midnight Pulse', 'Aurora Flow',
      'Horizon Drift', 'Electric Soul', 'Lunar Echo', 'Nova Spectrum'
    ];

    return artists[Math.floor(Math.random() * artists.length)];
  }

  // Create a recommendation object
  createRecommendation(reason, title, artist, seed) {
    return {
      reason,
      title,
      artist,
      imageSeed: seed || title.toLowerCase().replace(/\s+/g, '-')
    };
  }

  // Create the recommendations section in the DOM
  createRecommendationsSection() {
    const section = document.createElement('section');
    section.id = 'recommendations-section';
    section.className = 'content-section';
    section.innerHTML = `
      <div class="section-header">
        <h2>Recommended for you</h2>
        <div class="recommendation-insights">
          <span id="recommendation-insight" class="recommendation-tag">AI-powered</span>
          <button class="view-all-button">View all</button>
        </div>
      </div>
      <div class="recommendation-explanation">
        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
        </svg>
        <p>Personalized recommendations based on your listening habits and preferences</p>
      </div>
      <div id="recommendations-grid" class="playlist-grid"></div>
    `;

    // Insert after the first content section
    const firstSection = document.querySelector('.content-section');
    if (firstSection) {
      firstSection.parentNode.insertBefore(section, firstSection.nextSibling);
    } else {
      // Fallback - insert at the beginning of main content
      const mainContent = document.querySelector('.main-content');
      if (mainContent) {
        mainContent.insertBefore(section, mainContent.firstChild);
      }
    }

    // Add custom styles for recommendations
    const style = document.createElement('style');
    style.textContent = `
      .recommendation-insights {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .recommendation-tag {
        display: inline-block;
        padding: 4px 10px;
        background: var(--primary-gradient);
        color: white;
        font-size: 12px;
        font-weight: 500;
        border-radius: 100px;
      }

      .recommendation-explanation {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 20px;
        color: var(--muted);
        font-size: 14px;
      }

      .recommendation-explanation .icon {
        color: var(--tertiary);
      }

      .recommendation-label {
        position: absolute;
        top: 10px;
        left: 10px;
        background-color: rgba(0, 0, 0, 0.6);
        color: white;
        font-size: 11px;
        padding: 4px 8px;
        border-radius: 4px;
        backdrop-filter: blur(4px);
        z-index: 5;
      }
    `;
    document.head.appendChild(style);
  }

  // Update the recommendations UI
  updateRecommendationsUI(recommendations) {
    const grid = document.getElementById('recommendations-grid');
    if (!grid) return;

    const insight = document.getElementById('recommendation-insight');
    if (insight) {
      const phrases = [
        'AI-powered', 'For your taste', 'Personalized', 'Based on your history'
      ];
      insight.textContent = phrases[Math.floor(Math.random() * phrases.length)];
    }

    grid.innerHTML = '';

    recommendations.forEach((rec, index) => {
      const card = document.createElement('div');
      card.className = 'playlist-card';
      card.innerHTML = `
        <div class="playlist-img-container">
          <div class="recommendation-label">${rec.reason}</div>
          <img src="https://picsum.photos/seed/${rec.imageSeed || index}/300" alt="${rec.title}">
          <div class="play-overlay">
            <button class="play-button">
              <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="5 3 19 12 5 21 5 3"></polygon>
              </svg>
            </button>
          </div>
        </div>
        <div class="playlist-info">
          <h3>${rec.title}</h3>
          <p>${rec.artist}</p>
          <span class="songs-count">Recommended for you</span>
        </div>
      `;

      grid.appendChild(card);

      // Add hover effect
      card.addEventListener('mouseenter', () => {
        const overlay = card.querySelector('.play-overlay');
        overlay.style.opacity = '1';
      });

      card.addEventListener('mouseleave', () => {
        const overlay = card.querySelector('.play-overlay');
        overlay.style.opacity = '0';
      });
    });
  }
}

// Initialize when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const recommendations = new MusicRecommendations();
  recommendations.init();
});
