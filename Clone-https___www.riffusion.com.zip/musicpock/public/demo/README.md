# MusicPock Demo

This is a standalone demo of the MusicPock AI music creation interface. This demo showcases the modern design and advanced visualizations we've implemented.

## Features

1. **Cosmic Dream Theme** - A unique, vibrant color scheme that sets us apart from competitors
2. **Advanced Visualizations** - Multiple visualization types:
   - Linear waveform display
   - Circular visualizer with radial bars
   - Spectrum analyzer with responsive bars
3. **User Account System** - Sign in to save your presets and track your history
4. **Interactive Studio** - Full-featured studio interface for music creation

## Running the Demo

There are several ways to run this demo:

### Using the Shell Script

1. Open a terminal in this directory
2. Run: `./create-demo.sh`
3. Visit `http://localhost:8000/demo/` in your browser

### Manual Method

1. Start any HTTP server in the root directory
   - Python: `python -m http.server 8000`
   - Node: `npx serve`
2. Visit the demo directory in your browser (typically http://localhost:8000/demo/ or similar)

## Demo Pages

- `index.html` - Main homepage with the new design and user account system
- `studio.html` - Advanced studio interface with visualizations

## Features That Make MusicPock Unique

1. **Full Stem Separation** - Unlike competitors like Riffusion, MusicPock allows you to adjust individual instrument tracks
2. **Advanced Visualizations** - Multiple visualization types make the music creation process more engaging
3. **User-centric Approach** - Save presets, track history, and share your creations easily
4. **Cosmic Dream Theme** - Our unique color scheme creates a professional and immersive experience

## Technology Stack

- Pure JavaScript for animations and interactivity
- CSS custom properties for theming
- SVG-based icons for clean visuals
- Responsive design for all device sizes
