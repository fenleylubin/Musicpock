/**
 * MusicPock Social Sharing System
 * This script provides comprehensive social sharing capabilities for MusicPock.
 */

class SocialSharing {
  constructor() {
    this.shareModalId = 'social-share-modal';
    this.modalCreated = false;
    this.currentlySharing = null;
  }

  init() {
    // Create share modal if it doesn't exist
    if (!document.getElementById(this.shareModalId)) {
      this.createShareModal();
    }

    // Add share button event listeners to song rows
    const songActionButtons = document.querySelectorAll('.song-row .song-actions');
    songActionButtons.forEach(actionContainer => {
      const shareButton = actionContainer.querySelector('button:nth-child(2)');
      if (shareButton) {
        shareButton.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();

          const songRow = actionContainer.closest('.song-row');
          const title = songRow.querySelector('.song-info h3').textContent;
          const artist = songRow.querySelector('.song-info p').textContent;
          const image = songRow.querySelector('.song-thumbnail img').src;

          this.openShareModal({
            type: 'song',
            title,
            artist,
            image,
            id: songRow.dataset.id || this.generateId(title)
          });
        });
      }
    });

    // Add custom share buttons to playlist cards
    const playlistCards = document.querySelectorAll('.playlist-card');
    playlistCards.forEach(card => {
      // Only add if it doesn't already have a share button
      if (!card.querySelector('.playlist-share-button')) {
        const container = card.querySelector('.playlist-img-container');
        const shareButton = document.createElement('button');
        shareButton.className = 'playlist-share-button';
        shareButton.innerHTML = `
          <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="18" cy="5" r="3"></circle>
            <circle cx="6" cy="12" r="3"></circle>
            <circle cx="18" cy="19" r="3"></circle>
            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
          </svg>
        `;
        container.appendChild(shareButton);

        // Add event listener
        shareButton.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();

          const title = card.querySelector('.playlist-info h3').textContent;
          const creator = card.querySelector('.playlist-info p').textContent;
          const image = card.querySelector('.playlist-img-container img').src;
          const songsCount = card.querySelector('.songs-count')?.textContent || '';

          this.openShareModal({
            type: 'playlist',
            title,
            creator,
            image,
            songsCount,
            id: card.dataset.id || this.generateId(title)
          });
        });
      }
    });

    // Add style for playlist share button if not already added
    if (!document.getElementById('social-sharing-styles')) {
      const style = document.createElement('style');
      style.id = 'social-sharing-styles';
      style.textContent = `
        .playlist-share-button {
          position: absolute;
          top: 12px;
          right: 12px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background-color: rgba(0, 0, 0, 0.4);
          backdrop-filter: blur(4px);
          color: white;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          opacity: 0;
          transition: opacity 0.3s ease, background-color 0.2s ease;
          z-index: 5;
        }

        .playlist-share-button .icon {
          width: 16px;
          height: 16px;
        }

        .playlist-card:hover .playlist-share-button {
          opacity: 1;
        }

        .playlist-share-button:hover {
          background-color: var(--secondary);
        }

        .social-share-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          border-radius: 8px;
          cursor: pointer;
          transition: background-color 0.2s ease;
        }

        .social-share-item:hover {
          background-color: var(--surface-hover);
        }

        .social-icon-container {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .social-icon-container .icon {
          width: 24px;
          height: 24px;
          color: white;
        }

        .social-share-item-info {
          flex: 1;
        }

        .social-share-item-title {
          font-weight: 500;
          margin-bottom: 2px;
        }

        .social-share-item-description {
          font-size: 12px;
          color: var(--muted);
        }

        .social-embed-code {
          width: 100%;
          padding: 12px;
          border-radius: 6px;
          border: 1px solid var(--border);
          background-color: var(--background);
          color: var(--on-surface);
          font-family: monospace;
          font-size: 12px;
          resize: none;
          margin-top: 12px;
        }

        .share-modal-content {
          padding: 0;
        }

        .share-modal-header {
          padding: 16px 24px;
          border-bottom: 1px solid var(--border);
        }

        .share-modal-body {
          padding: 16px 24px;
        }

        .share-item-preview {
          display: flex;
          gap: 12px;
          margin-bottom: 16px;
          padding-bottom: 16px;
          border-bottom: 1px solid var(--border);
        }

        .share-item-image {
          width: 60px;
          height: 60px;
          border-radius: 6px;
          overflow: hidden;
          flex-shrink: 0;
        }

        .share-item-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .share-item-info {
          flex: 1;
        }

        .share-item-title {
          font-weight: 600;
          margin-bottom: 4px;
        }

        .share-item-subtitle {
          font-size: 14px;
          color: var(--muted);
        }

        .share-item-details {
          font-size: 12px;
          color: var(--muted-light);
          margin-top: 4px;
        }

        .share-options-title {
          font-size: 14px;
          font-weight: 500;
          margin-bottom: 12px;
        }

        .share-options-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          margin-bottom: 20px;
        }

        .success-message {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 12px;
          background-color: rgba(16, 185, 129, 0.1);
          border: 1px solid rgba(16, 185, 129, 0.2);
          border-radius: 6px;
          color: #10b981;
          font-size: 14px;
          margin: 12px 0;
        }

        .share-link-container {
          display: flex;
          gap: 8px;
          margin-top: 16px;
        }

        .share-link-input {
          flex: 1;
          padding: 8px 12px;
          border-radius: 6px;
          border: 1px solid var(--border);
          background-color: var(--background);
          color: var(--on-surface);
          font-size: 14px;
        }

        .share-modal-footer {
          padding: 16px 24px;
          border-top: 1px solid var(--border);
          display: flex;
          justify-content: flex-end;
          gap: 12px;
        }
      `;
      document.head.appendChild(style);
    }
  }

  createShareModal() {
    const modal = document.createElement('div');
    modal.id = this.shareModalId;
    modal.className = 'share-modal';
    modal.style.display = 'none';
    modal.innerHTML = `
      <div class="share-modal-overlay"></div>
      <div class="share-modal-container">
        <div class="share-modal-content">
          <div class="share-modal-header">
            <h3 class="share-modal-title">Share</h3>
            <button class="share-modal-close">&times;</button>
          </div>
          <div class="share-modal-body">
            <div class="share-item-preview">
              <div class="share-item-image">
                <img src="" alt="Share preview" id="share-preview-image">
              </div>
              <div class="share-item-info">
                <div class="share-item-title" id="share-item-title"></div>
                <div class="share-item-subtitle" id="share-item-subtitle"></div>
                <div class="share-item-details" id="share-item-details"></div>
              </div>
            </div>

            <h4 class="share-options-title">Share to</h4>
            <div class="share-options-grid">
              <div class="social-share-item" data-platform="twitter">
                <div class="social-icon-container" style="background-color: #1DA1F2;">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                  </svg>
                </div>
                <div class="social-share-item-info">
                  <div class="social-share-item-title">Twitter</div>
                  <div class="social-share-item-description">Share to your feed</div>
                </div>
              </div>

              <div class="social-share-item" data-platform="facebook">
                <div class="social-icon-container" style="background-color: #1877F2;">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </div>
                <div class="social-share-item-info">
                  <div class="social-share-item-title">Facebook</div>
                  <div class="social-share-item-description">Share with friends</div>
                </div>
              </div>

              <div class="social-share-item" data-platform="whatsapp">
                <div class="social-icon-container" style="background-color: #25D366;">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17.498 14.382c-.301-.15-1.767-.867-2.04-.966-.273-.101-.473-.15-.673.15-.197.295-.771.964-.944 1.162-.175.195-.349.21-.646.075-.3-.15-1.263-.465-2.403-1.485-.888-.795-1.484-1.77-1.66-2.07-.174-.3-.019-.465.13-.615.136-.135.301-.345.451-.523.146-.181.194-.301.297-.496.1-.21.049-.375-.025-.524-.075-.15-.672-1.62-.922-2.206-.24-.584-.487-.51-.672-.51-.172-.015-.371-.015-.571-.015-.2 0-.523.074-.797.359-.273.3-1.045 1.02-1.045 2.475s1.07 2.865 1.219 3.075c.149.195 2.105 3.195 5.1 4.485.714.3 1.27.48 1.704.629.714.227 1.365.195 1.88.121.574-.091 1.767-.721 2.016-1.426.255-.705.255-1.29.18-1.425-.074-.135-.27-.21-.57-.345m-5.446 7.443h-.016c-1.77 0-3.524-.48-5.055-1.38l-.36-.214-3.75.975 1.005-3.645-.239-.375a9.869 9.869 0 0 1-1.516-5.26c0-5.445 4.455-9.885 9.942-9.885a9.865 9.865 0 0 1 7.022 2.92 9.76 9.76 0 0 1 2.905 6.965c-.004 5.445-4.455 9.885-9.935 9.885M20.52 3.449C18.24 1.245 15.24 0 12.045 0 5.463 0 .104 5.334.101 11.893c0 2.096.549 4.14 1.595 5.945L0 24l6.335-1.652a12.062 12.062 0 0 0 5.71 1.447h.006c6.585 0 11.946-5.336 11.949-11.896 0-3.176-1.24-6.165-3.495-8.411"></path>
                  </svg>
                </div>
                <div class="social-share-item-info">
                  <div class="social-share-item-title">WhatsApp</div>
                  <div class="social-share-item-description">Share with contacts</div>
                </div>
              </div>

              <div class="social-share-item" data-platform="copy">
                <div class="social-icon-container" style="background-color: #6366F1;">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                  </svg>
                </div>
                <div class="social-share-item-info">
                  <div class="social-share-item-title">Copy Link</div>
                  <div class="social-share-item-description">Copy to clipboard</div>
                </div>
              </div>
            </div>

            <div id="share-success-message" class="success-message" style="display: none;">
              <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
              Link copied to clipboard!
            </div>

            <h4 class="share-options-title">Share link</h4>
            <div class="share-link-container">
              <input type="text" class="share-link-input" id="share-link-input" readonly>
              <button class="action-button" id="copy-link-button">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                Copy
              </button>
            </div>

            <div id="embed-container" style="margin-top: 20px; display: none;">
              <h4 class="share-options-title">Embed</h4>
              <textarea class="social-embed-code" id="embed-code" rows="3" readonly></textarea>
            </div>
          </div>
          <div class="share-modal-footer">
            <button class="action-button outline" id="share-modal-close-btn">Close</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    // Add modal style
    const style = document.createElement('style');
    style.textContent = `
      .share-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .share-modal-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(4px);
      }

      .share-modal-container {
        position: relative;
        width: 100%;
        max-width: 500px;
        max-height: 90vh;
        overflow-y: auto;
        background-color: var(--surface);
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      }

      .share-modal-title {
        font-size: 18px;
        font-weight: 600;
        margin: 0;
      }

      .share-modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .share-modal-close {
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: var(--muted);
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background-color 0.2s ease;
      }

      .share-modal-close:hover {
        background-color: var(--surface-hover);
      }
    `;
    document.head.appendChild(style);

    // Add event listeners
    const closeModal = () => {
      modal.style.display = 'none';
      document.body.style.overflow = '';
    };

    document.querySelector(`#${this.shareModalId} .share-modal-overlay`).addEventListener('click', closeModal);
    document.querySelector(`#${this.shareModalId} .share-modal-close`).addEventListener('click', closeModal);
    document.getElementById('share-modal-close-btn').addEventListener('click', closeModal);

    // Platform sharing
    const platformButtons = document.querySelectorAll('.social-share-item[data-platform]');
    platformButtons.forEach(button => {
      button.addEventListener('click', () => {
        const platform = button.getAttribute('data-platform');
        this.shareOnPlatform(platform);
      });
    });

    // Copy link button
    document.getElementById('copy-link-button').addEventListener('click', () => {
      this.copyShareLink();
    });

    this.modalCreated = true;
  }

  generateId(str) {
    // Simple function to generate a deterministic ID from a string
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(36);
  }

  openShareModal(item) {
    if (!this.modalCreated) {
      this.createShareModal();
    }

    this.currentlySharing = item;

    // Update modal content
    document.getElementById('share-preview-image').src = item.image;
    document.getElementById('share-item-title').textContent = item.title;

    if (item.type === 'song') {
      document.getElementById('share-item-subtitle').textContent = item.artist;
      document.getElementById('share-item-details').textContent = 'Song';
    } else {
      document.getElementById('share-item-subtitle').textContent = item.creator;
      document.getElementById('share-item-details').textContent = item.songsCount || 'Playlist';
    }

    // Set share link
    const shareUrl = this.generateShareUrl(item);
    document.getElementById('share-link-input').value = shareUrl;

    // Show/hide embed section based on type
    const embedContainer = document.getElementById('embed-container');
    if (item.type === 'playlist') {
      embedContainer.style.display = 'block';
      document.getElementById('embed-code').value = this.generateEmbedCode(item);
    } else {
      embedContainer.style.display = 'none';
    }

    // Hide success message
    document.getElementById('share-success-message').style.display = 'none';

    // Show the modal
    const modal = document.getElementById(this.shareModalId);
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
  }

  generateShareUrl(item) {
    const baseUrl = window.location.origin;
    if (item.type === 'song') {
      return `${baseUrl}/song/${item.id}`;
    } else {
      return `${baseUrl}/playlist/${item.id}`;
    }
  }

  generateEmbedCode(item) {
    if (item.type !== 'playlist') return '';

    return `<iframe src="${this.generateShareUrl(item)}/embed" width="100%" height="450" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>`;
  }

  copyShareLink() {
    const linkInput = document.getElementById('share-link-input');
    linkInput.select();
    document.execCommand('copy');

    // Show success message
    const successMessage = document.getElementById('share-success-message');
    successMessage.style.display = 'flex';

    // Hide after 3 seconds
    setTimeout(() => {
      successMessage.style.display = 'none';
    }, 3000);
  }

  shareOnPlatform(platform) {
    if (!this.currentlySharing) return;

    const shareUrl = this.generateShareUrl(this.currentlySharing);
    const title = this.currentlySharing.title;
    const text = `Check out "${title}" on MusicPock`;

    let url;

    switch (platform) {
      case 'twitter':
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case 'whatsapp':
        url = `https://wa.me/?text=${encodeURIComponent(text + " " + shareUrl)}`;
        break;
      case 'copy':
        this.copyShareLink();
        return;
    }

    // Open in new window
    if (url) {
      window.open(url, '_blank');
    }
  }
}

// Initialize when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const sharing = new SocialSharing();
  sharing.init();
});
