"use client";

import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Share2, Copy, Check, Facebook, Twitter, Linkedin, Mail, Link as LinkIcon } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ShareDialogProps {
  title: string;
  url: string;
  description?: string;
  children?: React.ReactNode;
  trigger?: React.ReactNode;
  className?: string;
}

export function ShareDialog({
  title,
  url,
  description = "Share this content with your friends and followers!",
  children,
  trigger,
  className,
}: ShareDialogProps) {
  const [copied, setCopied] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [webShareAvailable, setWebShareAvailable] = useState(false);

  useEffect(() => {
    // Check if Web Share API is available
    setWebShareAvailable(typeof navigator !== 'undefined' &&
                         typeof navigator.share === 'function');
  }, []);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setShowAlert(true);

      setTimeout(() => {
        setCopied(false);
      }, 2000);

      setTimeout(() => {
        setShowAlert(false);
      }, 3000);
    } catch (err) {
      console.error("Failed to copy text: ", err);
    }
  };

  const encodeURIText = (text: string) => encodeURIComponent(text);

  const shareViaFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
  };

  const shareViaTwitter = () => {
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIText(title)}&url=${encodeURIComponent(url)}`, '_blank');
  };

  const shareViaLinkedin = () => {
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
  };

  const shareViaEmail = () => {
    window.open(`mailto:?subject=${encodeURIText(title)}&body=${encodeURIText(`Check this out: ${url}`)}`, '_blank');
  };

  const useShareAPI = () => {
    if (webShareAvailable) {
      navigator.share({
        title,
        url,
        text: description,
      }).catch(error => console.log('Error sharing', error));
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="icon" className={className}>
            <Share2 className="h-4 w-4" />
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Share</DialogTitle>
          <DialogDescription>
            {description}
          </DialogDescription>
        </DialogHeader>

        {showAlert && (
          <Alert className="bg-primary/10 border-primary/20 text-primary">
            <AlertDescription className="flex items-center">
              <Check className="h-4 w-4 mr-2" /> Link copied to clipboard!
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 gap-4">
            <Button
              variant="outline"
              className="flex flex-col items-center gap-1 h-auto py-3"
              onClick={shareViaFacebook}
            >
              <Facebook className="h-5 w-5" />
              <span className="text-xs">Facebook</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center gap-1 h-auto py-3"
              onClick={shareViaTwitter}
            >
              <Twitter className="h-5 w-5" />
              <span className="text-xs">Twitter</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center gap-1 h-auto py-3"
              onClick={shareViaLinkedin}
            >
              <Linkedin className="h-5 w-5" />
              <span className="text-xs">LinkedIn</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center gap-1 h-auto py-3"
              onClick={shareViaEmail}
            >
              <Mail className="h-5 w-5" />
              <span className="text-xs">Email</span>
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            <div className="grid flex-1 gap-2">
              <label className="text-sm font-medium">Share link</label>
              <div className="flex gap-2">
                <Input
                  value={url}
                  readOnly
                  className="flex-1"
                />
                <Button variant="secondary" size="icon" onClick={copyToClipboard}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="sm:justify-between">
          {webShareAvailable && (
            <Button type="button" variant="secondary" onClick={useShareAPI}>
              <LinkIcon className="mr-2 h-4 w-4" />
              Use device sharing
            </Button>
          )}
          <Button type="button" variant="default" onClick={copyToClipboard}>
            {copied ? "Copied!" : "Copy link"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
