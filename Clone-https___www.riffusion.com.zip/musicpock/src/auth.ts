import NextAuth from "next-auth";
import GitHub from "next-auth/providers/github";
import Google from "next-auth/providers/google";
import Credentials from "next-auth/providers/credentials";

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    GitHub({
      clientId: process.env.GITHUB_ID || "mock-github-id",
      clientSecret: process.env.GITHUB_SECRET || "mock-github-secret",
    }),
    Google({
      clientId: process.env.GOOGLE_ID || "mock-google-id",
      clientSecret: process.env.GOOGLE_SECRET || "mock-google-secret",
    }),
    Credentials({
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        // For demo purposes - in a real app, you'd fetch the user from a database
        if (credentials?.email === "demo@musicpock.com" && credentials?.password === "password") {
          return {
            id: "1",
            name: "Demo User",
            email: "demo@musicpock.com",
            image: "https://picsum.photos/seed/user1/200",
          };
        }
        return null;
      },
    }),
  ],
  pages: {
    signIn: "/login",
    signOut: "/",
    error: "/login",
  },
  callbacks: {
    authorized({ auth, request: { nextUrl } }) {
      const isLoggedIn = !!auth?.user;
      const isOnProtectedPage =
        nextUrl.pathname.startsWith("/profile") ||
        nextUrl.pathname.startsWith("/favorites") ||
        nextUrl.pathname.startsWith("/personalize");

      if (isOnProtectedPage) {
        if (isLoggedIn) return true;
        return false; // Redirect to login
      }
      return true;
    },
    session: ({ session, token }) => {
      if (token.sub && session.user) {
        session.user.id = token.sub;
      }
      return session;
    }
  },
});
