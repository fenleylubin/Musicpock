"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";
import Image from "next/image";
import { Wand2, Save, RefreshCw, Music, Play, MusicIcon, Sparkles, Clock, Sliders, Download, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { Progress } from "@/components/ui/progress";

// Interface for music generation options
interface MusicGenerationOptions {
  prompt: string;
  duration?: string;
  style?: string;
  guidance?: number;
  seed?: number;
}

// Interface for generated music
interface GeneratedMusic {
  id: string;
  title: string;
  author: string;
  image: string;
  duration: string;
  createdAt: string;
  prompt: string;
  audioUrl?: string;
}

// Mock function to generate music
async function generateMusic(options: MusicGenerationOptions): Promise<GeneratedMusic> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 3000));

  // For demonstration, return a mocked result
  const title = options.prompt.split(' ').slice(0, 3).join(' ');

  return {
    id: Math.random().toString(36).substring(2, 9),
    title: title.charAt(0).toUpperCase() + title.slice(1),
    author: "AI Creator",
    image: `https://picsum.photos/seed/${encodeURIComponent(options.prompt)}/800`,
    duration: options.duration || "3:00",
    createdAt: new Date().toISOString(),
    prompt: options.prompt,
    audioUrl: `/api/audio/demo` // Mock audio URL
  };
}

export default function SongCreatePage() {
  const { data: session } = useSession();
  const router = useRouter();

  // State for user input
  const [prompt, setPrompt] = useState("");
  const [duration, setDuration] = useState("3:00");
  const [styleGuidance, setStyleGuidance] = useState("high");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generatedMusic, setGeneratedMusic] = useState<GeneratedMusic | null>(null);
  const [generationError, setGenerationError] = useState("");

  // Mock recent generations
  const [recentGenerations, setRecentGenerations] = useState([
    {
      id: "1",
      title: "Ocean Symphony",
      createdAt: "2 hours ago",
      image: "https://picsum.photos/seed/music1/200",
    },
    {
      id: "2",
      title: "Urban Nightlife",
      createdAt: "3 hours ago",
      image: "https://picsum.photos/seed/music2/200",
    },
    {
      id: "3",
      title: "Forest Dreams",
      createdAt: "5 hours ago",
      image: "https://picsum.photos/seed/music3/200",
    },
  ]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      setGenerationError("Please enter a description of the music you want to create");
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);
    setGenerationError("");

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setGenerationProgress((prev) => {
          const newProgress = prev + Math.random() * 15;
          return newProgress >= 100 ? 100 : newProgress;
        });
      }, 500);

      // Prepare options for music generation
      const options: MusicGenerationOptions = {
        prompt,
        duration,
        style: styleGuidance,
      };

      // Call the music generation API
      const result = await generateMusic(options);

      // Clear the interval and set final progress
      clearInterval(progressInterval);
      setGenerationProgress(100);

      // Update state with the generated music
      setGeneratedMusic(result);
      setRecentGenerations(prev => [{
        id: result.id,
        title: result.title,
        createdAt: "Just now",
        image: result.image,
      }, ...prev.slice(0, 2)]);

      // Redirect to the song detail page
      setTimeout(() => {
        router.push(`/song/${result.id}`);
      }, 1500);
    } catch (error) {
      console.error("Error generating music:", error);
      setGenerationError("Failed to generate music. Please try again.");
    } finally {
      // Even if there's an error, we stop generating after a delay
      setTimeout(() => {
        setIsGenerating(false);
      }, 500);
    }
  };

  const handleDurationSelect = (value: string) => {
    setDuration(value);
  };

  const handleGuidanceSelect = (value: string) => {
    setStyleGuidance(value);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold">Create New Music</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Music Generation</CardTitle>
              <CardDescription>
                Describe the music you want to create
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4">
                  <div>
                    <Textarea
                      placeholder="Create the music you imagine... (e.g., 'A dreamy lo-fi beat with piano, light drums, and ambient synth pads')"
                      className="min-h-[120px]"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      disabled={isGenerating}
                    />
                    {generationError && (
                      <p className="text-sm text-destructive mt-2">{generationError}</p>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Duration</label>
                      <div className="flex items-center space-x-1">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleDurationSelect("1:30")}
                          className={duration === "1:30" ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}
                          disabled={isGenerating}
                        >
                          1:30
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleDurationSelect("2:00")}
                          className={duration === "2:00" ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}
                          disabled={isGenerating}
                        >
                          2:00
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleDurationSelect("3:00")}
                          className={duration === "3:00" ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}
                          disabled={isGenerating}
                        >
                          3:00
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleDurationSelect("4:00")}
                          className={duration === "4:00" ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}
                          disabled={isGenerating}
                        >
                          4:00
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Style Guidance</label>
                      <div className="flex items-center space-x-1">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleGuidanceSelect("low")}
                          className={styleGuidance === "low" ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}
                          disabled={isGenerating}
                        >
                          Low
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleGuidanceSelect("medium")}
                          className={styleGuidance === "medium" ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}
                          disabled={isGenerating}
                        >
                          Medium
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleGuidanceSelect("high")}
                          className={styleGuidance === "high" ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""}
                          disabled={isGenerating}
                        >
                          High
                        </Button>
                      </div>
                    </div>
                  </div>
                  {isGenerating && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Generating your music...</span>
                        <span>{Math.round(generationProgress)}%</span>
                      </div>
                      <Progress value={generationProgress} />
                    </div>
                  )}
                </div>
              </form>
            </CardContent>
            <CardFooter className="border-t pt-6 flex justify-between">
              <Button
                variant="outline"
                disabled={isGenerating}
              >
                <Sliders className="mr-2 h-4 w-4" />
                Advanced Options
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={isGenerating || !prompt.trim()}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate Music
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>

          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Generations</CardTitle>
                <CardDescription>
                  Your recently created music
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {recentGenerations.map((item) => (
                    <div key={item.id} className="flex items-center border rounded-lg p-3 hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className="relative w-12 h-12 rounded overflow-hidden bg-muted mr-3">
                        <Image
                          src={item.image}
                          alt={`Generated music ${item.title}`}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-medium">{item.title}</h4>
                        <p className="text-xs text-muted-foreground">Created {item.createdAt}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Play className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Quick Settings</CardTitle>
              <CardDescription>
                Frequently used options
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Music Genre</label>
                <div className="grid grid-cols-2 gap-2">
                  {["Pop", "Rock", "Electronic", "Hip-Hop"].map(genre => (
                    <Button
                      key={genre}
                      variant="outline"
                      size="sm"
                      className="justify-start"
                      onClick={() => setPrompt(prev => `${prev} ${genre}`.trim())}
                      disabled={isGenerating}
                    >
                      {genre}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Mood</label>
                <div className="grid grid-cols-2 gap-2">
                  {["Happy", "Sad", "Energetic", "Calm"].map(mood => (
                    <Button
                      key={mood}
                      variant="outline"
                      size="sm"
                      className="justify-start"
                      onClick={() => setPrompt(prev => `${prev} ${mood}`.trim())}
                      disabled={isGenerating}
                    >
                      {mood}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Instruments</label>
                <div className="grid grid-cols-2 gap-2">
                  {["Piano", "Guitar", "Drums", "Synth", "Bass", "Vocals"].map(instrument => (
                    <Button
                      key={instrument}
                      variant="outline"
                      size="sm"
                      className="justify-start"
                      onClick={() => setPrompt(prev => `${prev} ${instrument}`.trim())}
                      disabled={isGenerating}
                    >
                      {instrument}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="pt-4 space-y-2">
                <h4 className="text-sm font-medium">Saved Templates</h4>
                <div className="space-y-2">
                  <Button
                    variant="secondary"
                    className="w-full justify-start"
                    onClick={() => setPrompt("Lo-Fi chill beat with piano, gentle drums, and atmospheric pads")}
                    disabled={isGenerating}
                  >
                    <Music className="mr-2 h-4 w-4" />
                    Lo-Fi Chill Beat
                  </Button>
                  <Button
                    variant="secondary"
                    className="w-full justify-start"
                    onClick={() => setPrompt("Epic orchestral soundtrack with brass, strings, and dramatic percussion")}
                    disabled={isGenerating}
                  >
                    <Music className="mr-2 h-4 w-4" />
                    Epic Orchestral
                  </Button>
                  <Button
                    variant="secondary"
                    className="w-full justify-start"
                    onClick={() => setPrompt("EDM dance track with heavy bass, synth leads, and energetic drums")}
                    disabled={isGenerating}
                  >
                    <Music className="mr-2 h-4 w-4" />
                    EDM Dance
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
