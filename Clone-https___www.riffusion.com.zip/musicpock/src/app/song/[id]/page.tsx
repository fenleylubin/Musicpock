"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Link from "next/link";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { Heart, Share2, Download, MoreHorizontal, Play, Pause, SkipBack, SkipForward, Volume2, Repeat, Shuffle } from "lucide-react";
import { getMusicById, type GeneratedMusic } from "@/lib/music-api";
import { useSession } from "next-auth/react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ShareDialog } from "@/components/share-dialog";

export default function SongDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = typeof params.id === "string" ? params.id : "";
  const { data: session } = useSession();
  const isAuthenticated = !!session?.user;

  const [song, setSong] = useState<GeneratedMusic | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);

  // Mock data for similar songs
  const similarSongs = [
    {
      id: "1",
      title: "Mountain Echo",
      artist: "NatureSounds",
      image: "https://picsum.photos/seed/mountain/200",
      duration: "3:36",
    },
    {
      id: "2",
      title: "City Lights",
      artist: "UrbanBeats",
      image: "https://picsum.photos/seed/city/200",
      duration: "3:35",
    },
    {
      id: "3",
      title: "Dreamy Horizon",
      artist: "SkyWalker",
      image: "https://picsum.photos/seed/dream/200",
      duration: "3:24",
    },
  ];

  useEffect(() => {
    async function fetchSong() {
      try {
        setIsLoading(true);
        setError("");

        if (id) {
          const songData = await getMusicById(id);
          if (songData) {
            setSong(songData);
          } else {
            setError("Song not found");
          }
        } else {
          setError("Invalid song ID");
        }
      } catch (err) {
        console.error("Error fetching song:", err);
        setError("Failed to load song. Please try again.");
      } finally {
        setIsLoading(false);
      }
    }

    fetchSong();
  }, [id]);

  const handlePlayToggle = () => {
    setIsPlaying(!isPlaying);
  };

  const handleFavoriteToggle = () => {
    if (isAuthenticated) {
      setIsFavorite(!isFavorite);
      // In a real app, you would call an API to update the favorite status
    } else {
      router.push("/login");
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-muted-foreground">Loading song...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-destructive mb-4">{error}</p>
        <Button asChild variant="secondary">
          <Link href="/">Go back home</Link>
        </Button>
      </div>
    );
  }

  // If no song, show not found
  if (!song) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-destructive mb-4">Song not found</p>
        <Button asChild variant="secondary">
          <Link href="/">Go back home</Link>
        </Button>
      </div>
    );
  }

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';
  const shareTitle = `Listen to ${song.title} by ${song.author} on MusicPock`;
  const shareDescription = `Check out this AI-generated music: ${song.title}`;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/3">
          <div className="relative aspect-square rounded-md overflow-hidden bg-muted">
            <Image
              src={song.image}
              alt={song.title}
              fill
              className="object-cover"
            />
          </div>
        </div>

        <div className="md:w-2/3 space-y-4">
          <div>
            <h1 className="text-3xl font-bold">{song.title}</h1>
            <div className="flex items-center mt-2">
              <Avatar className="h-6 w-6 mr-2">
                <AvatarImage src={`https://picsum.photos/seed/${song.author}/100`} alt={song.author} />
                <AvatarFallback>{song.author[0]}</AvatarFallback>
              </Avatar>
              <Link href={`/artist/${song.author}`} className="text-sm font-medium hover:underline">
                {song.author}
              </Link>
              <span className="mx-2 text-muted-foreground">•</span>
              <span className="text-sm text-muted-foreground">AI-Generated</span>
              <span className="mx-2 text-muted-foreground">•</span>
              <span className="text-sm text-muted-foreground">{song.duration}</span>
            </div>
          </div>

          <div className="flex space-x-2">
            <Button size="lg" className="rounded-full px-8" onClick={handlePlayToggle}>
              {isPlaying ? (
                <>
                  <Pause className="mr-2 h-4 w-4" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Play
                </>
              )}
            </Button>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="icon"
                    variant="outline"
                    className={`rounded-full ${isFavorite ? "bg-primary/10 text-primary" : ""}`}
                    onClick={handleFavoriteToggle}
                  >
                    <Heart className={`h-4 w-4 ${isFavorite ? "fill-primary" : ""}`} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isFavorite ? "Remove from favorites" : "Add to favorites"}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <ShareDialog
              title={shareTitle}
              url={shareUrl}
              description={shareDescription}
              trigger={
                <Button size="icon" variant="outline" className="rounded-full">
                  <Share2 className="h-4 w-4" />
                </Button>
              }
            />

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="outline" className="rounded-full">
                    <Download className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Download</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Button size="icon" variant="outline" className="rounded-full">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-2">Description</h3>
            <p className="text-sm text-muted-foreground">{song.prompt}</p>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-2">Generation Details</h3>
            <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
              <div>
                <span className="font-medium">Created: </span>
                {new Date(song.createdAt).toLocaleDateString()}
              </div>
              <div>
                <span className="font-medium">Duration: </span>
                {song.duration}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-muted/50 p-4 rounded-md">
        <div className="flex justify-center items-center space-x-4">
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <Shuffle className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <SkipBack className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            className="rounded-full h-12 w-12 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={handlePlayToggle}
          >
            {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <SkipForward className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <Repeat className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center mt-4 space-x-2">
          <span className="text-xs text-muted-foreground">0:00</span>
          <div className="h-1.5 flex-1 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary w-0 rounded-full"></div>
          </div>
          <span className="text-xs text-muted-foreground">{song.duration}</span>
          <Button variant="ghost" size="icon" className="text-muted-foreground ml-2">
            <Volume2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Separator />

      <div>
        <h3 className="text-xl font-medium mb-4">Generated from</h3>
        <div className="bg-muted/30 p-4 rounded-md">
          <p className="text-muted-foreground whitespace-pre-line">
            <span className="font-medium">Prompt: </span>
            {song.prompt}
          </p>
        </div>
      </div>

      <Separator />

      <div>
        <h3 className="text-xl font-medium mb-4">Similar tracks</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {similarSongs.map((similarSong) => (
            <Link href={`/song/${similarSong.id}`} key={similarSong.id}>
              <Card className="overflow-hidden hover:bg-muted/50 transition-colors group">
                <CardContent className="p-3">
                  <div className="flex gap-3 items-center">
                    <div className="relative w-16 h-16 rounded-md overflow-hidden bg-muted">
                      <Image
                        src={similarSong.image}
                        alt={similarSong.title}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                        <Play size={20} className="text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{similarSong.title}</h4>
                      <p className="text-xs text-muted-foreground">{similarSong.artist}</p>
                      <p className="text-xs text-muted-foreground mt-1">{similarSong.duration}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
