import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";
import Image from "next/image";
import { ChevronDown, Search, Sparkles, Sliders, Music, Lightbulb, Settings } from "lucide-react";

export default function PersonalizePage() {
  return (
    <div className="space-y-6">
      <div className="flex w-full max-w-3xl mx-auto space-x-2">
        <div className="relative flex-1">
          <Input
            placeholder="Create the music you imagine..."
            className="px-10 py-6 text-base"
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            <Search size={20} />
          </div>
        </div>
        <Button size="lg" className="px-6">
          <Sparkles size={18} className="mr-2" />
          Generate
        </Button>
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Personalize your experience</h2>

        <Tabs defaultValue="presets" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="presets">
              <Music className="mr-2 h-4 w-4" />
              Music Presets
            </TabsTrigger>
            <TabsTrigger value="style">
              <Sliders className="mr-2 h-4 w-4" />
              Style Controls
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="mr-2 h-4 w-4" />
              Advanced Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="presets" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Genre Presets</CardTitle>
                  <CardDescription>
                    Start with a genre template as your base
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-2">
                  {["Pop", "Rock", "Jazz", "Classical", "Electronic", "Hip-Hop", "R&B", "Folk"].map(genre => (
                    <Button key={genre} variant="outline" className="justify-start">
                      {genre}
                    </Button>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Mood Presets</CardTitle>
                  <CardDescription>
                    Set the emotional tone of your music
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-2">
                  {["Happy", "Sad", "Energetic", "Calm", "Dark", "Bright", "Dreamy", "Intense"].map(mood => (
                    <Button key={mood} variant="outline" className="justify-start">
                      {mood}
                    </Button>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="style" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Style Controls</CardTitle>
                <CardDescription>
                  Fine-tune your music generation parameters
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Tempo</label>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">Slow</span>
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-1/2 rounded-full"></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Fast</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Complexity</label>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">Simple</span>
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-2/3 rounded-full"></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Complex</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Instrumentation</label>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">Minimal</span>
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-3/4 rounded-full"></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Full</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Settings</CardTitle>
                <CardDescription>
                  Detailed generation parameters for experts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Guidance Scale</label>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">7.0</span>
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-3/5 rounded-full"></div>
                    </div>
                    <span className="text-sm text-muted-foreground">12.0</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Seed Value</label>
                  <Input placeholder="Random seed" defaultValue="42"/>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Negative Prompt</label>
                  <Input placeholder="Elements to avoid" />
                </div>
                <div className="pt-4">
                  <Button className="w-full">Apply Settings</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <div className="mt-10">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Lightbulb className="mr-2 h-5 w-5 text-yellow-500" />
              Pro Tips
            </CardTitle>
            <CardDescription>
              Get the most out of your music generation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm">• Be specific about genres, instruments, and mood for better results</p>
            <p className="text-sm">• Try using contrasting elements like "piano with glitchy beats"</p>
            <p className="text-sm">• Save your favorite settings as presets for quick access</p>
            <p className="text-sm">• Experiment with the seed value to get variations of the same prompt</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
