"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { SongRow } from "@/components/song-row";
import { PlaylistCard } from "@/components/playlist-card";
import { Heart, Search, Filter, Music } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function FavoritesPage() {
  const { data: session, status } = useSession();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterActive, setFilterActive] = useState(false);

  // Mock data for favorite songs
  const favoriteSongs = [
    {
      id: "1",
      index: "01",
      title: "Ocean Waves",
      author: "WaveMaker",
      image: "https://picsum.photos/seed/ocean/200",
      plays: "8.1k",
      likes: "286",
      duration: "3:47",
    },
    {
      id: "2",
      index: "02",
      title: "Mountain Echo",
      author: "NatureSounds",
      image: "https://picsum.photos/seed/mountain/200",
      plays: "5.0k",
      likes: "140",
      duration: "3:36",
    },
    {
      id: "3",
      index: "03",
      title: "City Lights",
      author: "UrbanBeats",
      image: "https://picsum.photos/seed/city/200",
      plays: "4.3k",
      likes: "185",
      duration: "3:35",
    },
    {
      id: "4",
      index: "04",
      title: "Dreamy Horizon",
      author: "SkyWalker",
      image: "https://picsum.photos/seed/dream/200",
      plays: "2.3k",
      likes: "115",
      duration: "3:24",
    },
    {
      id: "5",
      index: "05",
      title: "Electric Forest",
      author: "NatureTech",
      image: "https://picsum.photos/seed/electric/200",
      plays: "2.3k",
      likes: "100",
      duration: "3:12",
    },
  ];

  // Mock data for favorite playlists
  const favoritePlaylists = [
    {
      id: "1",
      title: "Chill Vibes",
      author: "MusicPock",
      songs: 11,
      imageUrl: "https://picsum.photos/seed/chill/200",
    },
    {
      id: "2",
      title: "Lo-Fi Beats",
      author: "ChillHop",
      songs: 8,
      imageUrl: "https://picsum.photos/seed/lofi/200",
    },
    {
      id: "3",
      title: "Deep Focus",
      author: "MindZone",
      songs: 15,
      imageUrl: "https://picsum.photos/seed/focus/200",
    },
  ];

  if (status === "loading") {
    return <div className="flex items-center justify-center h-full">Loading...</div>;
  }

  if (status === "unauthenticated") {
    redirect("/login");
  }

  // Filter songs based on search term
  const filteredSongs = favoriteSongs.filter(
    (song) => song.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
              song.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Filter playlists based on search term
  const filteredPlaylists = favoritePlaylists.filter(
    (playlist) => playlist.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                   playlist.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container mx-auto py-6 max-w-5xl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Heart className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold">Your Favorites</h1>
        </div>
        <div className="relative w-64">
          <Input
            placeholder="Search in favorites..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
          <Search className="h-4 w-4 absolute left-2.5 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
        </div>
      </div>

      <Tabs defaultValue="songs" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="songs" className="flex items-center gap-1">
            <Music className="h-4 w-4" />
            Songs
          </TabsTrigger>
          <TabsTrigger value="playlists" className="flex items-center gap-1">
            <Music className="h-4 w-4" />
            Playlists
          </TabsTrigger>
        </TabsList>

        <TabsContent value="songs" className="space-y-4">
          {filteredSongs.length === 0 ? (
            <div className="text-center py-12">
              <Music className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No songs found</h3>
              <p className="text-muted-foreground">
                {searchTerm ? "Try a different search term" : "Add songs to your favorites to see them here"}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredSongs.map((song) => (
                <div key={song.id} className="group">
                  <SongRow song={song} />
                  <Separator className="mt-2" />
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="playlists" className="space-y-4">
          {filteredPlaylists.length === 0 ? (
            <div className="text-center py-12">
              <Music className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No playlists found</h3>
              <p className="text-muted-foreground">
                {searchTerm ? "Try a different search term" : "Add playlists to your favorites to see them here"}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {filteredPlaylists.map((playlist) => (
                <PlaylistCard key={playlist.id} playlist={playlist} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
