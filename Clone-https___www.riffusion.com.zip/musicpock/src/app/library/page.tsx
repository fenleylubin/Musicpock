import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import Image from "next/image";
import { ChevronDown, Search, Sparkles } from "lucide-react";
import { PlaylistCard } from "@/components/playlist-card";

export default function LibraryPage() {
  const featuredPlaylists = [
    {
      id: "1",
      title: "Chill Vibes",
      author: "MusicPock",
      songs: 11,
      imageUrl: "https://picsum.photos/seed/chill/200",
    },
    {
      id: "2",
      title: "Lo-Fi Beats",
      author: "ChillHop",
      songs: 8,
      imageUrl: "https://picsum.photos/seed/lofi/200",
    },
    {
      id: "3",
      title: "Deep Focus",
      author: "MindZone",
      songs: 15,
      imageUrl: "https://picsum.photos/seed/focus/200",
    },
    {
      id: "4",
      title: "EDM Mix",
      author: "BeatMaster",
      songs: 13,
      imageUrl: "https://picsum.photos/seed/edm/200",
    },
    {
      id: "5",
      title: "Jazz Collection",
      author: "JazzCat",
      songs: 9,
      imageUrl: "https://picsum.photos/seed/jazz/200",
    },
    {
      id: "6",
      title: "Rock Classics",
      author: "RockStar",
      songs: 12,
      imageUrl: "https://picsum.photos/seed/rock/200",
    },
    {
      id: "7",
      title: "Ambient Sounds",
      author: "SoundScapes",
      songs: 14,
      imageUrl: "https://picsum.photos/seed/ambient/200",
    },
    {
      id: "8",
      title: "Electronic Vibes",
      author: "TechnoWizard",
      songs: 18,
      imageUrl: "https://picsum.photos/seed/electro/200",
    },
    {
      id: "9",
      title: "Classical Piano",
      author: "PianoMaster",
      songs: 10,
      imageUrl: "https://picsum.photos/seed/piano/200",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex w-full max-w-3xl mx-auto space-x-2">
        <div className="relative flex-1">
          <Input
            placeholder="Create the music you imagine..."
            className="px-10 py-6 text-base"
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            <Search size={20} />
          </div>
        </div>
        <Button size="lg" className="px-6">
          <Sparkles size={18} className="mr-2" />
          Generate
        </Button>
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Featured playlists</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {featuredPlaylists.map((playlist) => (
            <PlaylistCard key={playlist.id} playlist={playlist} />
          ))}
        </div>
      </div>
    </div>
  );
}
