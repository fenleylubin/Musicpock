"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Edit2, Save, Music, Headphones, TrendingUp } from "lucide-react";

export default function ProfilePage() {
  const { data: session, status } = useSession();
  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState(session?.user?.name || "");

  // Mock user preferences and statistics
  const [preferences, setPreferences] = useState({
    notifyNewReleases: true,
    autoplayOnVisit: false,
    darkMode: false,
    highQualityStreaming: true,
    shareActivityPublic: false,
  });

  if (status === "loading") {
    return <div className="flex items-center justify-center h-full">Loading...</div>;
  }

  if (status === "unauthenticated") {
    redirect("/login");
  }

  const recentGenres = [
    "Lo-Fi", "Jazz", "Electronic", "Ambient", "Classical"
  ];

  const userStats = {
    songsCreated: 15,
    favoriteSongs: 24,
    playlistsCreated: 3,
    totalListens: 147,
  };

  const handleSaveProfile = () => {
    // In a real app, this would save to backend
    setIsEditing(false);
  };

  return (
    <div className="container mx-auto py-6 max-w-5xl">
      <h1 className="text-3xl font-bold mb-6">Your Profile</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Information */}
        <Card className="md:col-span-1">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Profile</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => isEditing ? handleSaveProfile() : setIsEditing(true)}
              >
                {isEditing ? <Save className="h-4 w-4" /> : <Edit2 className="h-4 w-4" />}
              </Button>
            </div>
            <CardDescription>Your personal information</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <Avatar className="h-24 w-24">
              <AvatarImage
                src={session?.user?.image || "https://picsum.photos/seed/user/200"}
                alt={session?.user?.name || "User"}
              />
              <AvatarFallback>{session?.user?.name?.[0] || "U"}</AvatarFallback>
            </Avatar>
            <div className="space-y-2 w-full">
              {isEditing ? (
                <div className="space-y-2">
                  <Label htmlFor="name">Display Name</Label>
                  <Input
                    id="name"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                  />
                </div>
              ) : (
                <div className="text-center">
                  <h3 className="text-xl font-medium">{session?.user?.name}</h3>
                  <p className="text-sm text-muted-foreground">{session?.user?.email}</p>
                </div>
              )}
            </div>
          </CardContent>
          <Separator />
          <CardHeader>
            <CardTitle className="text-sm">Top Genres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {recentGenres.map((genre) => (
                <Badge key={genre} variant="secondary">{genre}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Account Settings and Statistics */}
        <div className="md:col-span-2 space-y-6">
          <Tabs defaultValue="preferences">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
              <TabsTrigger value="statistics">Statistics</TabsTrigger>
            </TabsList>

            <TabsContent value="preferences" className="space-y-4 pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Account Preferences</CardTitle>
                  <CardDescription>Customize your MusicPock experience</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Notify about new releases</Label>
                      <p className="text-sm text-muted-foreground">Receive notifications about new music releases</p>
                    </div>
                    <Switch
                      checked={preferences.notifyNewReleases}
                      onCheckedChange={(checked) => setPreferences({...preferences, notifyNewReleases: checked})}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Autoplay on visit</Label>
                      <p className="text-sm text-muted-foreground">Automatically play music when you visit the site</p>
                    </div>
                    <Switch
                      checked={preferences.autoplayOnVisit}
                      onCheckedChange={(checked) => setPreferences({...preferences, autoplayOnVisit: checked})}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Dark Mode</Label>
                      <p className="text-sm text-muted-foreground">Use dark theme for the application</p>
                    </div>
                    <Switch
                      checked={preferences.darkMode}
                      onCheckedChange={(checked) => setPreferences({...preferences, darkMode: checked})}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>High Quality Streaming</Label>
                      <p className="text-sm text-muted-foreground">Stream music at the highest quality (uses more data)</p>
                    </div>
                    <Switch
                      checked={preferences.highQualityStreaming}
                      onCheckedChange={(checked) => setPreferences({...preferences, highQualityStreaming: checked})}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Public Activity</Label>
                      <p className="text-sm text-muted-foreground">Allow others to see your listening activity</p>
                    </div>
                    <Switch
                      checked={preferences.shareActivityPublic}
                      onCheckedChange={(checked) => setPreferences({...preferences, shareActivityPublic: checked})}
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button>Save Preferences</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="statistics" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Usage Statistics</CardTitle>
                  <CardDescription>Overview of your activity on MusicPock</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2 border rounded-lg p-4">
                      <div className="flex items-center gap-2">
                        <Music className="h-4 w-4 text-primary" />
                        <h3 className="text-sm font-medium">Songs Created</h3>
                      </div>
                      <p className="text-2xl font-bold">{userStats.songsCreated}</p>
                    </div>
                    <div className="space-y-2 border rounded-lg p-4">
                      <div className="flex items-center gap-2">
                        <Headphones className="h-4 w-4 text-primary" />
                        <h3 className="text-sm font-medium">Total Listens</h3>
                      </div>
                      <p className="text-2xl font-bold">{userStats.totalListens}</p>
                    </div>
                    <div className="space-y-2 border rounded-lg p-4">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-primary" />
                        <h3 className="text-sm font-medium">Playlists Created</h3>
                      </div>
                      <p className="text-2xl font-bold">{userStats.playlistsCreated}</p>
                    </div>
                    <div className="space-y-2 border rounded-lg p-4">
                      <div className="flex items-center gap-2">
                        <Headphones className="h-4 w-4 text-primary" />
                        <h3 className="text-sm font-medium">Favorite Songs</h3>
                      </div>
                      <p className="text-2xl font-bold">{userStats.favoriteSongs}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
