"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";

export type FavoriteItem = {
  id: string;
  type: "song" | "playlist";
  title: string;
  author: string;
  image: string;
  addedAt: string;
};

// A mock function to get favorites - in a real app this would call an API
const getFavoritesFromApi = async (userId: string): Promise<FavoriteItem[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 300));

  // Check if we have stored favorites in localStorage
  if (typeof window !== "undefined") {
    try {
      const storedFavorites = localStorage.getItem(`favorites-${userId}`);
      if (storedFavorites) {
        return JSON.parse(storedFavorites);
      }
    } catch (error) {
      console.error("Error reading from localStorage:", error);
    }
  }

  // Return empty array if no favorites found
  return [];
};

// A mock function to add favorite - in a real app this would call an API
const addFavoriteToApi = async (userId: string, item: FavoriteItem): Promise<boolean> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 300));

  // Store in localStorage for demo purposes
  if (typeof window !== "undefined") {
    try {
      // Get existing favorites
      const storedFavorites = localStorage.getItem(`favorites-${userId}`);
      const favorites = storedFavorites ? JSON.parse(storedFavorites) : [];

      // Add new favorite if it doesn't exist
      if (!favorites.some((fav: FavoriteItem) => fav.id === item.id && fav.type === item.type)) {
        const updatedFavorites = [...favorites, item];
        localStorage.setItem(`favorites-${userId}`, JSON.stringify(updatedFavorites));
      }
      return true;
    } catch (error) {
      console.error("Error writing to localStorage:", error);
      return false;
    }
  }

  return true;
};

// A mock function to remove favorite - in a real app this would call an API
const removeFavoriteFromApi = async (userId: string, itemId: string, type: "song" | "playlist"): Promise<boolean> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 300));

  // Remove from localStorage for demo purposes
  if (typeof window !== "undefined") {
    try {
      // Get existing favorites
      const storedFavorites = localStorage.getItem(`favorites-${userId}`);
      if (storedFavorites) {
        const favorites = JSON.parse(storedFavorites);
        const updatedFavorites = favorites.filter(
          (fav: FavoriteItem) => !(fav.id === itemId && fav.type === type)
        );
        localStorage.setItem(`favorites-${userId}`, JSON.stringify(updatedFavorites));
      }
      return true;
    } catch (error) {
      console.error("Error updating localStorage:", error);
      return false;
    }
  }

  return true;
};

export function useFavorites() {
  const { data: session } = useSession();
  const [userId, setUserId] = useState<string>("anonymous");
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Update userId when session changes
  useEffect(() => {
    if (session?.user?.id) {
      setUserId(session.user.id);
    } else {
      setUserId("anonymous");
    }
  }, [session]);

  // Load favorites when user changes
  useEffect(() => {
    const loadFavorites = async () => {
      if (userId) {
        setLoading(true);
        try {
          const data = await getFavoritesFromApi(userId);
          setFavorites(data);
        } catch (error) {
          console.error("Error loading favorites:", error);
        } finally {
          setLoading(false);
        }
      }
    };

    loadFavorites();
  }, [userId]);

  // Add favorite
  const addFavorite = async (item: Omit<FavoriteItem, "addedAt">) => {
    if (!userId) return false;

    try {
      const favoriteItem: FavoriteItem = {
        ...item,
        addedAt: new Date().toISOString(),
      };

      const success = await addFavoriteToApi(userId, favoriteItem);
      if (success) {
        setFavorites(prev => [...prev, favoriteItem]);
      }
      return success;
    } catch (error) {
      console.error("Error adding favorite:", error);
      return false;
    }
  };

  // Remove favorite
  const removeFavorite = async (itemId: string, type: "song" | "playlist") => {
    if (!userId) return false;

    try {
      const success = await removeFavoriteFromApi(userId, itemId, type);
      if (success) {
        setFavorites(prev => prev.filter(item => !(item.id === itemId && item.type === type)));
      }
      return success;
    } catch (error) {
      console.error("Error removing favorite:", error);
      return false;
    }
  };

  // Check if item is a favorite
  const isFavorite = (itemId: string, type: "song" | "playlist") => {
    return favorites.some(item => item.id === itemId && item.type === type);
  };

  // Get all favorites
  const getFavorites = (type?: "song" | "playlist") => {
    if (type) {
      return favorites.filter(item => item.type === type);
    }
    return favorites;
  };

  return {
    favorites,
    loading,
    addFavorite,
    removeFavorite,
    isFavorite,
    getFavorites,
  };
}
