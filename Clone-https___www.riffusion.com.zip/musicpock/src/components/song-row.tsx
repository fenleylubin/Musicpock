"use client";

import Link from "next/link";
import Image from "next/image";
import { Play, Heart, MoreHorizontal, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useRouter } from "next/navigation";

interface SongRowProps {
  song: {
    id: string;
    index: string;
    title: string;
    author: string;
    image: string;
    plays: string;
    likes: string;
    duration: string;
  };
  isFavorite?: boolean;
}

export function SongRow({ song, isFavorite = false }: SongRowProps) {
  const { data: session } = useSession();
  const router = useRouter();
  const [isPlaying, setIsPlaying] = useState(false);
  const [isFav, setIsFav] = useState(isFavorite);
  const isAuthenticated = !!session?.user;

  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!isAuthenticated) {
      router.push("/login");
      return;
    }

    // In a real app, you would call an API to toggle the favorite status
    setIsFav(!isFav);
  };

  const handlePlayToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsPlaying(!isPlaying);
  };

  const handleShare = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const shareUrl = typeof window !== 'undefined' ?
      `${window.location.origin}/song/${song.id}` :
      `/song/${song.id}`;

    const shareTitle = `Listen to ${song.title} by ${song.author} on MusicPock`;

    // In a real app, this would open a share dialog
    if (navigator.share) {
      navigator
        .share({
          title: shareTitle,
          text: `Check out this track: ${song.title} by ${song.author}`,
          url: shareUrl,
        })
        .catch((error) => console.log("Error sharing", error));
    } else {
      // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(shareUrl);
      // Show a toast notification (would need to implement)
    }
  };

  return (
    <div className="flex items-center group hover:bg-muted/50 p-2 rounded-lg transition-colors">
      <div className="w-10 text-center text-muted-foreground text-sm">
        {song.index}
      </div>
      <div className="relative w-16 h-16 rounded overflow-hidden mr-4">
        <Image
          src={song.image}
          alt={song.title}
          fill
          className="object-cover"
        />
        <div
          className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer"
          onClick={handlePlayToggle}
        >
          <Play size={20} className="text-white" />
        </div>
      </div>
      <div className="flex-1">
        <Link href={`/song/${song.id}`} className="block">
          <h3 className="font-medium text-base group-hover:text-primary transition-colors">
            {song.title}
          </h3>
        </Link>
        <Link href={`/artist/${song.author}`} className="block">
          <p className="text-sm text-muted-foreground hover:text-primary transition-colors">
            {song.author}
          </p>
        </Link>
      </div>
      <div className="flex items-center gap-2 text-muted-foreground text-sm">
        <div className="flex items-center gap-1 min-w-[60px]">
          <span>{song.plays}</span>
        </div>
        <div className="flex items-center gap-1 min-w-[60px]">
          <span>{song.likes}</span>
        </div>
        <div>{song.duration}</div>
      </div>
      <div className="flex gap-1 ml-4">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "h-8 w-8 text-muted-foreground",
                  isFav ? "text-primary hover:text-primary" : "hover:text-primary"
                )}
                onClick={handleFavoriteToggle}
              >
                <Heart size={18} className={cn("", isFav && "fill-current")} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{isFav ? "Remove from favorites" : "Add to favorites"}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-primary"
                onClick={handleShare}
              >
                <Share2 size={18} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Share</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
          <MoreHorizontal size={18} />
        </Button>
      </div>
    </div>
  );
}
