"use client";

import Link from "next/link";
import Image from "next/image";
import { Play, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

interface PlaylistCardProps {
  playlist: {
    id: string;
    title: string;
    author: string;
    songs: number;
    imageUrl: string;
  };
  isFavorite?: boolean;
}

export function PlaylistCard({ playlist, isFavorite = false }: PlaylistCardProps) {
  const { data: session } = useSession();
  const router = useRouter();
  const [isFav, setIsFav] = useState(isFavorite);

  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!session?.user) {
      router.push("/login");
      return;
    }

    // In a real app, you would call an API to toggle the favorite status
    setIsFav(!isFav);
  };

  return (
    <Link href={`/playlist/${playlist.id}`}>
      <Card className="overflow-hidden hover:bg-muted/50 transition-colors group">
        <CardContent className="p-0">
          <div className="relative aspect-square">
            <Image
              src={playlist.imageUrl}
              alt={playlist.title}
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
              <Button className="rounded-full h-12 w-12" size="icon">
                <Play className="h-6 w-6" />
              </Button>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className={`absolute top-2 right-2 h-8 w-8 bg-black/50 hover:bg-black/70 transition-colors ${isFav ? "text-primary" : "text-white"}`}
              onClick={handleFavoriteToggle}
            >
              <Heart className={`h-4 w-4 ${isFav ? "fill-primary" : ""}`} />
            </Button>
          </div>
          <div className="p-3">
            <h4 className="font-medium text-sm line-clamp-1">{playlist.title}</h4>
            <p className="text-xs text-muted-foreground">{playlist.author}</p>
            <p className="text-xs text-muted-foreground mt-1">{playlist.songs} songs</p>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
