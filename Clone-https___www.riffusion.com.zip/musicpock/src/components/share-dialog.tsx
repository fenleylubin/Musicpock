"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Share2, Copy, Check } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ShareDialogProps {
  title: string;
  url: string;
  description?: string;
  trigger?: React.ReactNode;
  className?: string;
}

export function ShareDialog({
  title,
  url,
  description = "Share this content with your friends and followers!",
  trigger,
  className,
}: ShareDialogProps) {
  const [copied, setCopied] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setShowAlert(true);

      setTimeout(() => {
        setCopied(false);
      }, 2000);

      setTimeout(() => {
        setShowAlert(false);
      }, 3000);
    } catch (err) {
      console.error("Failed to copy text: ", err);
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="icon" className={className}>
            <Share2 className="h-4 w-4" />
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Share</DialogTitle>
          <DialogDescription>
            {description}
          </DialogDescription>
        </DialogHeader>

        {showAlert && (
          <Alert className="bg-primary/10 border-primary/20 text-primary">
            <AlertDescription className="flex items-center">
              <Check className="h-4 w-4 mr-2" /> Link copied to clipboard!
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4 py-4">
          <div className="flex items-center space-x-2">
            <div className="grid flex-1 gap-2">
              <label className="text-sm font-medium">Share link</label>
              <div className="flex gap-2">
                <Input
                  value={url}
                  readOnly
                  className="flex-1"
                />
                <Button variant="secondary" size="icon" onClick={copyToClipboard}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button type="button" variant="default" onClick={copyToClipboard}>
            {copied ? "Copied!" : "Copy link"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
