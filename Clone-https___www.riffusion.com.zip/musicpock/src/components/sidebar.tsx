"use client";

import Link from "next/link";
import Image from "next/image";
import { Home, Library, Layers, LogIn, LogOut, FileText, Mail, Info, User, Heart, PlusCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useSession, signOut } from "next-auth/react";

export function Sidebar() {
  const pathname = usePathname();
  const { data: session, status } = useSession();
  const isAuthenticated = status === "authenticated";

  const routes = [
    {
      name: "Home",
      path: "/",
      icon: Home,
    },
    {
      name: "Library",
      path: "/library",
      icon: Library,
    },
    {
      name: "Personalize",
      path: "/personalize",
      icon: Layers,
      requiresAuth: true,
    },
  ];

  const accountRoutes = [
    {
      name: "Profile",
      path: "/profile",
      icon: User,
      requiresAuth: true,
    },
    {
      name: "Favorites",
      path: "/favorites",
      icon: Heart,
      requiresAuth: true,
    },
    {
      name: "Create Music",
      path: "/song/create",
      icon: PlusCircle,
      requiresAuth: false,
    },
  ];

  const infoRoutes = [
    {
      name: "Docs",
      path: "/docs",
      icon: FileText,
    },
    {
      name: "Discord",
      path: "https://discord.com",
      icon: Mail,
      external: true,
    },
    {
      name: "Learn more",
      path: "/learn",
      icon: Info,
    },
  ];

  const handleSignOut = () => {
    signOut({ callbackUrl: "/" });
  };

  return (
    <div className="flex h-full w-64 flex-col border-r bg-zinc-50/50 pt-5">
      <div className="px-6 pb-5">
        <Link href="/" className="flex items-center gap-2">
          <div className="text-primary flex items-center">
            <span className="font-bold text-xl text-primary">MusicPock</span>
            <span className="ml-1 rounded-sm bg-muted px-1.5 py-0.5 text-xs font-medium leading-none text-muted-foreground">
              BETA
            </span>
          </div>
        </Link>
      </div>

      {/* Main navigation */}
      <div className="space-y-1 px-3">
        {routes.map((route) => {
          if (route.requiresAuth && !isAuthenticated) return null;
          return (
            <Link
              key={route.path}
              href={route.path}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-muted",
                pathname === route.path ? "bg-muted" : "text-muted-foreground"
              )}
            >
              <route.icon size={18} />
              {route.name}
            </Link>
          );
        })}
      </div>

      {/* Account section */}
      {isAuthenticated && (
        <>
          <div className="mt-2 px-3">
            <h3 className="px-4 py-2 text-xs font-medium text-muted-foreground">Account</h3>
            <div className="space-y-1">
              {accountRoutes.filter(route => route.requiresAuth).map((route) => (
                <Link
                  key={route.path}
                  href={route.path}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-muted",
                    pathname === route.path ? "bg-muted" : "text-muted-foreground"
                  )}
                >
                  <route.icon size={18} />
                  {route.name}
                </Link>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Create music section - available to all */}
      <div className="mt-2 px-3">
        {accountRoutes.filter(route => !route.requiresAuth).map((route) => (
          <Link
            key={route.path}
            href={route.path}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-muted",
              pathname === route.path ? "bg-muted text-primary" : "text-muted-foreground",
              "bg-primary/10 hover:bg-primary/20 text-primary"
            )}
          >
            <route.icon size={18} />
            {route.name}
          </Link>
        ))}
      </div>

      {/* User section */}
      <div className="mt-auto">
        {isAuthenticated ? (
          <div className="p-3">
            <div className="flex items-center gap-3 rounded-lg bg-muted p-3">
              <Avatar>
                <AvatarImage
                  src={session?.user?.image || "https://picsum.photos/seed/user/200"}
                  alt={session?.user?.name || "User"}
                />
                <AvatarFallback>{session?.user?.name?.[0] || "U"}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{session?.user?.name || "User"}</p>
                <p className="text-xs text-muted-foreground truncate">{session?.user?.email || ""}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={handleSignOut}>
                <LogOut size={18} />
              </Button>
            </div>
          </div>
        ) : (
          <div className="p-3">
            <Link href="/login">
              <Button className="w-full" variant="outline">
                <LogIn className="mr-2 h-4 w-4" />
                Sign In
              </Button>
            </Link>
          </div>
        )}
      </div>

      {/* Info links */}
      <div className="space-y-1 px-3 py-4 border-t">
        {infoRoutes.map((route) => (
          <Link
            key={route.path}
            href={route.path}
            target={route.external ? "_blank" : undefined}
            rel={route.external ? "noopener noreferrer" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-muted",
              pathname === route.path ? "bg-muted" : "text-muted-foreground"
            )}
          >
            <route.icon size={18} />
            {route.name}
          </Link>
        ))}
      </div>
    </div>
  );
}
