import { v4 as uuidv4 } from 'uuid';

// Mock data for generated songs
const songData = [
  {
    id: "ocean-waves",
    title: "Ocean Waves",
    author: "WaveMaker",
    image: "https://picsum.photos/seed/ocean/800",
    plays: "8.1k",
    likes: "286",
    duration: "3:47",
    description: "Ambient sounds of ocean waves with gentle piano melodies.",
  },
  {
    id: "mountain-echo",
    title: "Mountain Echo",
    author: "NatureSounds",
    image: "https://picsum.photos/seed/mountain/800",
    plays: "5.0k",
    likes: "140",
    duration: "3:36",
    description: "Echoing melodies inspired by mountain landscapes.",
  },
  {
    id: "city-lights",
    title: "City Lights",
    author: "UrbanBeats",
    image: "https://picsum.photos/seed/city/800",
    plays: "4.3k",
    likes: "185",
    duration: "3:35",
    description: "Electronic beats with urban atmospheres.",
  },
  {
    id: "dreamy-horizon",
    title: "Dreamy Horizon",
    author: "SkyWalker",
    image: "https://picsum.photos/seed/dream/800",
    plays: "2.3k",
    likes: "115",
    duration: "3:24",
    description: "Dreamlike ambient pads with distant melodies.",
  },
  {
    id: "electric-forest",
    title: "Electric Forest",
    author: "NatureTech",
    image: "https://picsum.photos/seed/electric/800",
    plays: "2.3k",
    likes: "100",
    duration: "3:12",
    description: "Electronic beats mixed with forest atmospheres.",
  },
];

// Interface for music generation options
export interface MusicGenerationOptions {
  prompt: string;
  duration?: string;
  style?: string;
  guidance?: number;
  seed?: number;
}

// Interface for generated music
export interface GeneratedMusic {
  id: string;
  title: string;
  author: string;
  image: string;
  duration: string;
  createdAt: string;
  prompt: string;
  audioUrl?: string;
}

/**
 * Mock function to generate music based on the provided options
 * In a real app, this would call an actual AI music generation API
 */
export async function generateMusic(options: MusicGenerationOptions): Promise<GeneratedMusic> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 3000));

  // For demonstration purposes, return a random song from our mock data
  // In a real app, this would call an actual API
  const randomSong = songData[Math.floor(Math.random() * songData.length)];

  // Create a title based on the prompt
  const words = options.prompt.split(' ');
  const title = words.length > 3
    ? words.slice(0, 3).join(' ').charAt(0).toUpperCase() + words.slice(0, 3).join(' ').slice(1)
    : options.prompt.charAt(0).toUpperCase() + options.prompt.slice(1);

  return {
    id: uuidv4(),
    title,
    author: "AI Creator",
    image: randomSong.image,
    duration: options.duration || "3:00",
    createdAt: new Date().toISOString(),
    prompt: options.prompt,
    audioUrl: `/api/audio/${randomSong.id}`, // Mock audio URL
  };
}

/**
 * Function to get a list of recently generated music
 * In a real app, this would fetch from a database
 */
export async function getRecentMusic(userId?: string): Promise<GeneratedMusic[]> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Create some mock recent generations
  return songData.map((song, index) => ({
    id: uuidv4(),
    title: song.title,
    author: "AI Creator",
    image: song.image,
    duration: song.duration,
    createdAt: new Date(Date.now() - index * 86400000).toISOString(), // Each one a day older
    prompt: `Create a ${song.description.toLowerCase()}`,
    audioUrl: `/api/audio/${song.id}`, // Mock audio URL
  }));
}

/**
 * Function to get a generated song by ID
 */
export async function getMusicById(id: string): Promise<GeneratedMusic | null> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Try to find the song in our mock data
  const song = songData.find(s => s.id === id);

  if (!song) return null;

  return {
    id: song.id,
    title: song.title,
    author: "AI Creator",
    image: song.image,
    duration: song.duration,
    createdAt: new Date().toISOString(),
    prompt: `Create a ${song.description.toLowerCase()}`,
    audioUrl: `/api/audio/${song.id}`, // Mock audio URL
  };
}
