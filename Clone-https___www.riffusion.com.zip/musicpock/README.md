# MusicPock

MusicPock is a modern web application that allows users to create, discover, and share AI-generated music. Inspired by Riffusion.com, this platform provides an intuitive interface for music generation with customizable parameters.

## Features

- **AI Music Generation**: Create music by describing what you want to hear
- **Personalization Options**: Customize generation parameters like genre, mood, and instruments
- **Music Library**: Browse and discover music created by other users
- **Playlist Management**: Create and share collections of your favorite tracks
- **Responsive Design**: Works seamlessly on desktop and mobile devices

## Technologies Used

- Next.js 15
- React 18
- Shadcn/UI
- Tailwind CSS
- TypeScript

## Getting Started

### Prerequisites

- Node.js 18+ or Bun 1.0+

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/musicpock.git
cd musicpock
```

2. Install dependencies:
```bash
bun install
```

3. Start the development server:
```bash
bun run dev
```

4. Open your browser and navigate to `http://localhost:3000`

## Project Structure

- `src/app`: Next.js pages and layouts
- `src/components`: Reusable React components
- `src/lib`: Utility functions and hooks
- `public`: Static assets

## Deployment

The application can be deployed to Netlify or Vercel with minimal configuration.

## License

This project is open-source and available under the MIT License.

## Acknowledgements

- Inspired by [Riffusion.com](https://www.riffusion.com)
- UI components from [Shadcn/UI](https://ui.shadcn.com/)
- Demo images from [Picsum Photos](https://picsum.photos/)
